import requests
import re
import random
import time
import sys
import os
import schedule
import configparser
from paste.util.multidict import MultiDict
from tkinter import messagebox
from bs4 import BeautifulSoup
from twocaptcha import TwoCaptcha

with open('./tokens.txt', 'r') as f:
    tokens = f.read().split("\n")
with open('./url.txt', 'r') as f:
    url = f.read().split("\n")
ini = configparser.ConfigParser()
ini.read('./config.ini', 'UTF-8')
class bcolors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

import datetime

def license(key):
    res = requests.Session()
    r = res.get("https://carfox1212.github.io/xrrrxs/license.txt")
    if(key in r.text):
        print("success")
        time.sleep(3)
        autoupdate()
        schedule.every(int(ini['setting']['uptime'])).minutes.do(autoupdate)
    else:
        print("not found")

def update(remember_token, URL, proxies=None):
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
    }
    cookies = {
        'remember_token': remember_token 
    }
    res = requests.Session()
    ID = str(URL).split("/")[5]
    r = res.get(f'https://gametrade.jp/exhibits/{ID}/edit', cookies=cookies, headers=headers)
    #print("GET DATA")
    soup = BeautifulSoup(r.content, 'html.parser')
    try:
        session_id = r.cookies.get_dict()["_session_id"]
        authenticity_token = r.text.split('"csrf-token" content="')[1].split('"')[0]
        solver = TwoCaptcha(ini['setting']['key'])
        result = solver.recaptcha(url=f'https://gametrade.jp/exhibits/{ID}/edit', sitekey="6LdBmqYZAAAAALTuNWDI9WSTVFkyAkyCNvc72Ebm")
        recaptcha_response = result["code"]
        cookies2 = {
            '_session_id': session_id,
            'remember_token': remember_token,
        }
        payload = {
            input['name']: input['value'] if input.has_attr('value') else ''
            for input in soup.select('form input')
            if input.has_attr('name')
        }
        IMAGES = soup.find_all('input', {'name': 'exhibit_images_ids[]', 'type': 'hidden'})
        MAINTEXT = soup.find('textarea').text
        if("ㅤㅤㅤ" in MAINTEXT):
            DESCRIPTION = MAINTEXT.replace('ㅤㅤㅤ','')
        else:
            DESCRIPTION = MAINTEXT
        payload['exhibit[description]'] = DESCRIPTION + 'ㅤ'
        try:
            dex = IMAGES[0]['value'],
            for n in range(int(len(IMAGES)-1)):
                dex += IMAGES[n+1]['value'], 
            payload['g-recaptcha-response'] = recaptcha_response
            payload['exhibit_images_ids[]'] = dex
            headers = {
                'accept': '*/*;q=0.5, text/javascript, application/javascript, application/ecmascript, application/x-ecmascript',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
                'x-csrf-token': authenticity_token,
                'x-requested-with': 'XMLHttpRequest',
            }
            r = res.post(f'https://gametrade.jp/exhibits/{ID}', cookies=cookies2, data=payload, headers=headers, allow_redirects=False)
            date = datetime.datetime.now()
            print(f'[{date.strftime("%H:%M:%S")}]SUCCEED {ID}')
        except IndexError:
            date = datetime.datetime.now()
            print(f"[{date.strftime('%H:%M:%S')}]商品ページが存在しません")
    except KeyError:
        date = datetime.datetime.now()
        print(f"[{date.strftime('%H:%M:%S')}]取引が終了しています")

#update("47260949d2758d20d080e87f941ad6dc87f68256", "https://gametrade.jp/apex-legends/exhibits/51537608")

def autoupdate(p=[0]):
    os.system("cls")
    p[0]+=1
    firstdate = datetime.datetime.now()
    print(f"{bcolors.GREEN}GAMETRADE AUTOMATIC UPDATE{bcolors.ENDC}")
    print(f"[{firstdate.strftime('%H:%M:%S')}]{bcolors.CYAN}START UPDATING{bcolors.ENDC} {bcolors.CYAN}{len(tokens)}{bcolors.ENDC}ACC {bcolors.CYAN}{p[0]}{bcolors.ENDC}TH")
    for a in range(len(tokens)):
        update(tokens[a], url[a])
    date = datetime.datetime.now()
    print(f"[{date.strftime('%H:%M:%S')}]{bcolors.CYAN}COMPLETED{bcolors.ENDC}")
print("enter license key")
key = input()
if(len(key) == 27):
    license(key)
else:
    print("this key is broken")
    time.sleep(3)
    sys.exit()
while True:
    schedule.run_pending()
    time.sleep(1)